var elastic = require('./elastic.js');
var indexName = 'text_input';

module.exports = {
  save: function(event, context) {
    var userId = event.headers.Authorization;
    var body = event.body;
    var text = body.text;
    var data = JSON.stringify({
      text: text
    });
    console.log('Data: ' + data + ' ID: ' + userId);

    elastic.post(indexName, userId, data, context);
  }

  // getSwearWordCount: function(userId){
  //   var req = new AWS.HttpRequest(endpoint);
  //
  //   req.method = 'GET';
  //   req.path = path.join('/', text_input, userId, '_search');
  //   req.region = esDomain.region;
  //   req.headers['presigned-expires'] = false;
  //   req.headers['Host'] = endpoint.host;
  //   req.body = JSON.stringify({
  //     "query": {
	// 	      "constant_score" : {
  // 	        "filter" : {
  // 	            "terms" : { "text" : ["test"]}
  // 	           }
  //     	   }
  //     }
  //   });
  //
  //   var send = new AWS.NodeHttpClient();
  //   send.handleRequest(req, null, function (httpResp) {
  //
  //     var respBody = '';
  //     httpResp.on('data', function (chunk) {
  //       respBody += chunk;
  //     });
  //
  //
  //     httpResp.on('end', function (chunk) {
  //       var response = JSON.parse(httpResp);
  //       var hits = response.hits;
  //       var hitsArray = hits.hits;
  //       var idsWithSwearWords = hitsArray.map(function(x){
  //         return x._id;
  //       });
  //
  //       var nextReq = new AWS.HttpRequest(endpoint);
  //
  //       nextReq.method = 'GET';
  //       nextReq.path = path.join('/', text_input, userId, '_mtermvectors');
  //       nextReq.region = esDomain.region;
  //       nextReq.headers['presigned-expires'] = false;
  //       nextReq.headers['Host'] = endpoint.host;
  //       nextReq.body = JSON.stringify({
  //       	"ids" : idsWithSwearWords,
  //       	"parameters": {
  //               "fields": [
  //                       "text"
  //               ],
  //               "term_statistics": true
  //           }
  //       });
  //
  //       var nextSend = new AWS.NodeHttpClient();
  //       nextSend.handleRequest(nextReq, null, function (httpResp) {
  //         var respBody = '';
  //         httpResp.on('data', function (chunk) {
  //           respBody += chunk;
  //         });
  //
  //         httpResp.on('end', function (chunk) {
  //           console.log('Response: ' + respBody);
  //           context.succeed('Lambda added document1 ' + data);
  //         });
  //       },
  //
  //       function (err) {
  //         console.log('Error: ' + err);
  //         context.fail('Lambda failed with error ' + err);
  //       });
  //       }
  //
  //       console.log('Response: ' + respBody);
  //       context.succeed('Lambda added document1 ' + data);
  //     });
  //   },
  //
  //   function (err) {
  //     console.log('Error: ' + err);
  //     context.fail('Lambda failed with error ' + err);
  //   }
  // );
  // }
}
