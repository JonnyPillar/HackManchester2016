var indexName = 'challengers';
var elastic = require('./elastic.js');

module.exports = {
  add: function(challengerId, recipientId, context){
    var body = JSON.stringify({
      challengerId: challengerId,
      recipientId: recipientId
    });

    elastic.post(indexName, 'active', body, context);
  },

  get: function(userId){
    
  }
};
