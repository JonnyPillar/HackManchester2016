var indexName = 'location';
var elastic = require('./elastic.js');

function getReq(userId, challengeId) {
  var url = path.join('/', indexName, userId, '_search', '?size=1000');
  var req = awsRequst.post(url, JSON.stringify({
    "query": {
      "bool": {
        "must": {
          "term": {
            "recipientId": userId
          }
        }

      }
    }
  }));
  return req;
}

module.exports = {
  add: function(userId, body, context){
    var postBody = JSON.stringify(body);

    elastic.post(indexName, userId, postBody, context);
  },

  get: function(userId, challengeId, context){
    var req = getReq(userId, challengeId);

  }
};
